<?php

/**
 * @author Marie_B, 14 Avril 2020
 * test
 * Une page index permettant de s’identifier sur l’application 
 * grâce au pseudo agent et au mot de passe 
 * --> redirigera vers une interface (template) 
 * qui s’affichera différemment selon le niveau d’accréditation. 
 * Vous créerez également un autre template chargé d’afficher la fiche d’un criminel et ses informations 
 * <div class="container"></a>
 *   <a href="page1.php">Page une</a>
 *   <a href="page2.php">Page deux</a>
    *</div>
 * un template de page backoffice accessible pour agent d’accreditation 1
 *  */ ?>

<?php 

$title='Connexion';
?>

<?php ob_start();?>

<form action="controllers/agent_verify.php" method="post">
<fieldset>
<div class="form-group">
<label for="exampleInputEmail1">Identifiant agent :</label>
<input type="text" class="form-control" id="idagent" name="idagent">
</div>
<div class="form-group">
<label for="exampleInputPassword1">Password</label>
<input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password">
</div>
<button type="submit" class="btn btn-primary">Submit</button>
</fieldset>
</form>

<?php $content=ob_get_clean(); 

require ('templates.php'); ?>



$pbdd = $pdo->prepare('SELECT * FROM !!!!!!!! WHERE INCONNU=?');
$pbdd->bindParam(1, $INCONNU);

//Exécution

$pbdd->execute([$INCONNU]);
$reponse=$pbdd->fetch();
?>


<?php $pdo = new PDO('mysql:host=localhost;dbname=criminels;charset=utf8','msb','stagiaire');

/**Connexion à la base de données via le formulaire, l'email sert d'ID*/

$pseudo_a=htmlspecialchars($_POST['pseudo_a']);
$mot_de_passe_a=htmlspecialchars($_POST['mot_de_passe_a']);



//Requête de récupération des données

$verif= $connexion->prepare('SELECT pseudo_a,mot_de_passe FROM agents WHERE pseudo_a=? AND mot_de_passe_a=?');

$verif->bindParam(1, $pseudo_a);
$verif->bindParam(2, $mot_de_passe_a);
$verif->execute();

$repverif=$verif->fetch();

    $_SESSION['pseudo_a']=$repverif['pseudo_a'];
    $_SESSION['']=$repverif['mot_de_passe_a'];

//Verification de l'existence ou non de l'adresse email

if (($repverif[0]==$pseudo_a)&&($repverif[1]==$mot_de_passe_a)) {
    header('Location:../Views/achat_ctrl.php');
}
else 
{ }



