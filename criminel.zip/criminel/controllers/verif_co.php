// fichier traitement connexion
<?php

// ranger et sécuriser les variables du formulaire

//

$agent= new AgentManager();


// condition de la verification
if(password_verify)$pseudo_a, $mot_de_passe_a)){
    session_start();
    $_SESSION['accreditation'] = $accredication;

}else{
    header('location:')
}
