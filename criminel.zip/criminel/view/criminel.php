<?php

session_start();
$accreditation = $_SESSION['accreditation'];

switch($accreditation){
    case 1;
    case 2;
        ob_start(); ?>
        <div>test1</div>
        <?php $content = ob_end_clean();
        break;
    case 3;
        ob_start(); ?>
        <div>test1</div>
        <?php $content = ob_end_clean();
        break;
    default;
        echo 'echec de connexion. Vision case 3 par défaut.';
    break;
}
require ('template/fiche_criminels.php');